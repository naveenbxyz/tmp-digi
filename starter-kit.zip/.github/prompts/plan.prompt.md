---
mode: agent
description: Plan the approach and gate targets for a spec increment (no edits).
---
Switch to the **Planner** agent. For the spec increment in context (or: ${input:spec}),
produce the smallest viable approach, name what to reuse, list the `just check` gates and any
new test/probe required (flag injection probes for anything touching ingested content), and
enumerate risks. Do not edit files. Hand off to Implementer when the plan is agreed.
