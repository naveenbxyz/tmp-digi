---
mode: agent
description: Implement the approved plan as the smallest diff, green before handoff.
---
Switch to the **Implementer** agent. Implement the approved plan as the smallest atomic diff.
Reuse before building; keep decisions deterministic; reference prompts/schemas by id/version.
Run `just check` and iterate until green for the current SIFT_STAGE. Stage one Conventional
Commit linked to the spec/task id, then hand off to Reviewer. Do not self-approve.
