---
mode: agent
description: Cold-context adversarial review — delete pass, probes, gates.
---
Switch to the **Reviewer** agent. Review the current diff with fresh context: run the delete
pass, check Envelope/contract conformance, confirm no decision rests on model output, attempt
a prompt-injection via a sample ingested document, run `just check` for the current stage, and
verify the diff is atomic and spec-linked. Return approve or changes-requested with specific,
ordered findings.
