---
mode: ask
description: Turn a need into a small spec increment against the Envelope Contract.
---
Draft a spec increment for: ${input:need}

Rules:
- Frame it against the Envelope Contract and the relevant module spec (000–011).
- Keep it the smallest useful slice. State acceptance criteria as checks that can be
  automated (a contract test, a schema assertion, an eval case, an injection probe).
- If it requires a contract/Envelope/schema change, say so explicitly and describe the
  spec-change — do not smuggle it into implementation.
- Output: goal, acceptance criteria (as checkable items), affected specs/modules, and any
  contract impact. No code.
